use slint::{Timer, TimerMode, SharedString};
use std::time::Duration;

// Include generated Slint code
slint::include_modules!();

// Callback implementations module
mod callbacks;

/// Get formatted system time and date strings using libc
fn system_clock_strings() -> Option<(String, String)> {
    let mut now = std::mem::MaybeUninit::<libc::time_t>::uninit();
    let mut local_tm = std::mem::MaybeUninit::<libc::tm>::uninit();

    unsafe {
        libc::time(now.as_mut_ptr());
        if libc::localtime_r(now.as_ptr(), local_tm.as_mut_ptr()).is_null() {
            return None;
        }

        let local_tm = local_tm.assume_init();
        let year = local_tm.tm_year + 1900;
        let month = local_tm.tm_mon + 1;
        let day = local_tm.tm_mday;

        Some((
            format!(
                "{:02}:{:02}:{:02}",
                local_tm.tm_hour, local_tm.tm_min, local_tm.tm_sec
            ),
            format!("{year:04}.{month:02}.{day:02}"),
        ))
    }
}

/// Refresh the system clock and update AppState with current time and date
fn refresh_system_clock(app: &MainWindow) {
    let Some((time_text, date_text)) = system_clock_strings() else {
        return;
    };

    // AppState is now publicly exported because it's defined in MainScreen.slint
    let state = app.global::<AppState>();
    state.set_current_time(SharedString::from(time_text));
    state.set_current_date(SharedString::from(date_text));
}

/// Setup a timer to refresh the system clock every second
fn setup_system_clock_timer(app: &MainWindow) -> Timer {
    let app_weak = app.as_weak();
    let timer = Timer::default();

    timer.start(TimerMode::Repeated, Duration::from_secs(1), move || {
        let Some(app) = app_weak.upgrade() else { return; };
        refresh_system_clock(&app);
    });

    timer
}

fn main() {
    // Create the application window
    let app = MainWindow::new().expect("Failed to create MainWindow");

    // Initialize clock with current time
    refresh_system_clock(&app);

    // Setup timer to update clock every second
    let _system_clock_timer = setup_system_clock_timer(&app);

    // Wire all FFI callbacks
    callbacks::wire_all(&app);

    println!("[{project_name}] Starting event loop...");
    app.run().expect("Failed to run event loop");
    println!("[{project_name}] Application exited");
}

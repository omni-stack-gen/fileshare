use slint::{ComponentHandle, SharedString};

/// Wire all Device FFI callbacks to their Rust implementations.
/// UI callbacks (navigate, increment, etc.) have Slint bodies and are NOT wired here.
pub fn wire_all(app: &MainWindow) {
    let app_weak = app.as_weak();

    // Device FFI: on_dismiss
    app.global::<AppState>().on_on_dismiss(move || {
        println!("[Callback] on_dismiss invoked");
        // TODO: Send request to control_service via Unix socket
    });

    // Device FFI: on_retry
    app.global::<AppState>().on_on_retry(move || {
        println!("[Callback] on_retry invoked");
        // TODO: Send request to control_service via Unix socket
    });
}

fn main() {
    slint_build::compile("slint/MainScreen.slint").expect("Failed to compile Slint");
}

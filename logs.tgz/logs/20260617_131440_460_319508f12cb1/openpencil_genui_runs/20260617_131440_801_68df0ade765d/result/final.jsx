<Frame name="HelloWorldScreen" flex="col" h={600} w={1024} gap={32} justify="center" items="center" bg="#F8FAFC">
  <Frame name="ContentArea" flex="col" gap={24} items="center">
    <Text name="GreetingLabel" size={48} weight="bold" textAlign="center" color="#0F172A">Hello World</Text>
    <Rectangle name="Rectangle" w={80} h={4} bg="#3B82F6" rounded={2} />
    <Text name="CountLabel" size={20} textAlign="center" textTarget="AppState.click_count" color="#64748B">0</Text>
    <Text name="MessageLabel" size={16} textAlign="center" textTarget="AppState.message" color="#475569">Press the button to get started</Text>
  </Frame>
  <Frame name="ButtonRow" flex="row" gap={16} items="center">
    <Frame name="PrimaryButton" interactive={{"type":"button","action":"click","calls":[{"target":"AppState.on_clicked"}]}} flex="row" h={52} justify="center" items="center" py={0} px={40} bg="#3B82F6" rounded={12}>
      <Text name="PrimaryLabel" size={16} weight="bold" color="#FFFFFF">Say Hello</Text>
    </Frame>
    <Frame name="ResetButton" interactive={{"type":"button","action":"reset","calls":[{"target":"AppState.on_reset"}]}} flex="row" h={52} justify="center" items="center" py={0} px={40} bg="#E2E8F0" rounded={12}>
      <Text name="ResetLabel" size={16} weight="medium" color="#475569">Reset</Text>
    </Frame>
  </Frame>
</Frame>